/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'de-ch', {
	border: 'Rahmen anzeigen',
	noUrl: 'Bitte geben Sie die IFrame-URL an',
	scrolling: 'Rollbalken anzeigen',
	title: 'IFrame-Eigenschaften',
	toolbar: 'IFrame',
	tabindex: 'Aus Tab-Reihenfolge entfernen'
} );
