/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'uk', {
	border: 'Показати рамки фрейму',
	noUrl: 'Будь ласка введіть URL посилання для IFrame',
	scrolling: 'Увімкнути прокрутку',
	title: 'Налаштування для IFrame',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
