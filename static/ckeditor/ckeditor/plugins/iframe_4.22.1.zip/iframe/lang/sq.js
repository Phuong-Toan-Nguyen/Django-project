/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'iframe', 'sq', {
	border: 'Shfaq kufirin e kornizës',
	noUrl: 'Ju lutemi shkruani URL-në e iframe-it',
	scrolling: 'Lejo shiritët zvarritës',
	title: 'Karakteristikat e IFrame',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
